package com.kimsujin.work1.domain;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

//Lombok
@Getter
@Setter
@NoArgsConstructor

//JPA
@Entity
@Table
public class LocationBoard {

    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idx;

    @Column
    private String address;

    @Column
    private String postcode;

    @Column
    @Enumerated(EnumType.STRING)
    private LocationBoardType boardType;

    @Builder
    public LocationBoard(String address, String postcode, LocationBoardType boardType){
        this.address = address;
        this.postcode = postcode;
        this.boardType = boardType;

    }
}
