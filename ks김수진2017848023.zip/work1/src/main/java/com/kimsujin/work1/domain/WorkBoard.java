package com.kimsujin.work1.domain;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;

//Lombok
@Getter
@Setter
@NoArgsConstructor

//JPA
@Entity
@Table
public class WorkBoard {
    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idx;

    @Column
    private String company;

    @Column
    private String position;

    @Column
    private String webSite;

    @Column
    private LocalDateTime startDate;

    @Column
    private LocalDateTime endDate;

    @Column
    private String summary;

    @Column
    @Enumerated(EnumType.STRING)
    private WorkBoardType boardType;

    @Builder
    public WorkBoard(String company, String position, String webSite,  LocalDateTime startDate,LocalDateTime endDate,  String summary ,WorkBoardType boardType){
        this.company = company;
        this.position = position;
        this.webSite = webSite;
        this.startDate = startDate;
        this.endDate = endDate;
        this.summary = summary;
        this.boardType = boardType;

    }
}
