package com.kimsujin.work1.domain;

import com.kimsujin.work1.repository.BasicRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@RunWith(SpringRunner.class)
@DataJpaTest
public class BasicBoardTest {

    @Autowired
    private BasicRepository basicRepository;
    private BasicBoard saveBasicBoard;

    @Before
    public void init(){
        saveBasicBoard = basicRepository.save(BasicBoard.builder()
                .name("홍길동")
                .label("웹프로그래머")
                .email("홍길동@메일주소.도메인")
                .phone("000-1234-5678")
                .build());
    }

        @Test
        public void testFindBasicBoardId(){
            BasicBoard foundBoard = basicRepository.findById(saveBasicBoard.getIdx()).orElse(null);
            assertThat(foundBoard.getIdx()).isEqualTo(saveBasicBoard.getIdx());

        }


}
