package com.kimsujin.work1.repository;


import com.kimsujin.work1.domain.BasicBoard;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BasicRepository extends JpaRepository<BasicBoard, Long> {

}
