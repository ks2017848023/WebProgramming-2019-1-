package com.kimsujin.work1.domain;

import com.kimsujin.work1.repository.LocationRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@DataJpaTest
public class LocationBoardTest {
    @Autowired
    private LocationRepository locationRepository;
    private LocationBoard saveLocationBoard;

    @Before
    public void init(){
        saveLocationBoard = locationRepository.save(LocationBoard.builder()
                .address("부산광역시 ㅇㅇ구 ㅇㅇ번길 ㅇㅇㅇ")
                .postcode("12345")
                .build());
    }

    @Test
    public void testFindLocationId(){
        LocationBoard foundLocationboard =  locationRepository.findById(saveLocationBoard.getIdx()).orElse(null);
        assertThat(foundLocationboard.getIdx()).isEqualTo(saveLocationBoard.getIdx());
    }
}
