package com.kimsujin.work1.domain;


import com.kimsujin.work1.repository.ProfileRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@DataJpaTest
public class ProfileBoardTest {


    @Autowired
    private ProfileRepository profileRepository;
    private ProfileBoard saveProfileBoard;

    @Before
    public void init(){
        saveProfileBoard = profileRepository.save(ProfileBoard.builder()
                .network("Twitter")
                .userName("홍길동")
                .url("http://www.twitter.com/홍길동")
                .build());
    }

    @Test
    public void testFindProfildId(){
        ProfileBoard foundProfileboard = profileRepository.findById(saveProfileBoard.getIdx()).orElse(null);
        assertThat(foundProfileboard.getIdx()).isEqualTo(saveProfileBoard.getIdx());
    }

}
