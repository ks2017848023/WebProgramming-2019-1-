package com.kimsujin.work1.repository;

import com.kimsujin.work1.domain.ProfileBoard;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfileRepository extends JpaRepository<ProfileBoard, Long> {
}
