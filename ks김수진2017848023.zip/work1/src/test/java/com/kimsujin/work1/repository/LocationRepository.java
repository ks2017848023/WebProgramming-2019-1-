package com.kimsujin.work1.repository;

import com.kimsujin.work1.domain.LocationBoard;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LocationRepository extends JpaRepository<LocationBoard, Long> {

}
