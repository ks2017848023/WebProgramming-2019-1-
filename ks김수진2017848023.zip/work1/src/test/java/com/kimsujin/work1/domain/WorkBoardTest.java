package com.kimsujin.work1.domain;


import com.kimsujin.work1.repository.WorkRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;


@RunWith(SpringRunner.class)
@DataJpaTest
public class WorkBoardTest {

    @Autowired
    private WorkRepository workRepository;
    private WorkBoard saveWorkBoard;

    @Before
    public void init(){
        saveWorkBoard = workRepository.save(WorkBoard.builder()
                .company("(주)홍길동")
                .position("개발자")
                .webSite("http://www.company.domain")
                .startDate(LocalDateTime.now())
                .endDate(LocalDateTime.now())
                .summary("...요약")
                .build());
    }

    @Test
    public void testFindWorkId(){
        WorkBoard foundWorkboard = workRepository.findById(saveWorkBoard.getIdx()).orElse(null);
        assertThat(foundWorkboard.getIdx()).isEqualTo(saveWorkBoard.getIdx());
    }

}
