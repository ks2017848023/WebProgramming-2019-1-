package com.kimsujin.work1.repository;

import com.kimsujin.work1.domain.WorkBoard;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WorkRepository extends JpaRepository<WorkBoard, Long> {
}
