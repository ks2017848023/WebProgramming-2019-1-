package com.n2017848023.main.controller;


import com.n2017848023.main.domain.Basic;
import com.n2017848023.main.domain.Profile;
import com.n2017848023.main.repository.BasicRepository;
import com.n2017848023.main.repository.BoardRepository;
import com.n2017848023.main.repository.ProfileRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class BoardJsonController {

    private BoardRepository boardRepository;
    private BasicRepository basicRepository;
    private ProfileRepository profileRepository;

    public BoardJsonController(BoardRepository boardRepository, BasicRepository basicRepository, ProfileRepository profileRepository) {
        this.boardRepository = boardRepository;
        this.basicRepository = basicRepository;
        this.profileRepository = profileRepository;
    }


    /*
    @GetMapping("/json/helloworld")
    public List<Basic> helloWorld(){
        return basicRepository.findAll();
    }

    @GetMapping("/json/helloworld")
    public List<Profile> helloWorld(){
        return profileRepository.findAll();
    }
  */
}
