package com.n2017848023.main.controller;


import com.n2017848023.main.domain.*;

import com.n2017848023.main.repository.BasicRepository;
import com.n2017848023.main.repository.BoardRepository;
import com.n2017848023.main.repository.ProfileRepository;
import com.n2017848023.main.service.BasicService;
import com.n2017848023.main.service.BoardService;
import com.n2017848023.main.service.ProfileService;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.time.LocalDateTime;

@Controller
public class BoardController {

    private BasicService basicService;
    private BasicRepository basicRepository;
    private ProfileService profileService;
    private ProfileRepository profileRepository;

    public BoardController(BasicService basicService, BasicRepository basicRepository, ProfileService profileService, ProfileRepository profileRepository) {
        this.basicService = basicService;
        this.basicRepository = basicRepository;
        this.profileService = profileService;
        this.profileRepository = profileRepository;
    }
    @GetMapping("/")
    public String listBasic(@PageableDefault Pageable pageable, Model model){
        model.addAttribute("basicList",basicService.findBasicList(pageable));
        model.addAttribute("profileList",profileService.findProfileList(pageable));
        return "index";
    }

    @GetMapping("/basic/{idx}")
    public String readBasic(@PathVariable Long idx, Model model){
        model.addAttribute("basic",basicService.findBasicByIdx(idx));
        return "itemBasic";
    }

    @GetMapping("/profile/{idx}")
    public String readProfile(@PathVariable Long idx, Model model){
        model.addAttribute("profile",profileService.findProfileByIdx(idx));
        return "itemProfile";
    }

    @PostMapping("/profile/add")
    public String addProfile(Profile profile, Model model){
        profile.setBoardType(BoardType.free);
        profile.setCreateDat(LocalDateTime.now());
        profile.setUpdateDat(LocalDateTime.now());
        Profile saveProfile = profileRepository.save(profile);
        model.addAttribute("profile",profileService.findProfileByIdx(saveProfile.getIdx()));
        return "itemProfile";
    }

    @PostMapping("/basic/add")
    public String addBasic(Basic basic, Model model){
        basic.setBoardType(BoardType.free);
        basic.setCreatedDate(LocalDateTime.now());
        basic.setUpdatedDate(LocalDateTime.now());
        Basic saveBasic = basicRepository.save(basic);
        model.addAttribute("basic",basicService.findBasicByIdx(saveBasic.getIdx()));
        return "itemBasic";
    }

    @GetMapping("/basic/new")
    public String formBasic(Basic basic){
        return "newBasic";
    }

    @GetMapping("/profile/new")
    public String formProfile(Profile profile){
        return "newProfile";
    }


}
