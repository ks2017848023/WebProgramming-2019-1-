package com.n2017848023.main.repository;


import com.n2017848023.main.domain.Board;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BoardRepository extends JpaRepository<Board, Long> {

    List<Board> findAllByTitle(final String title);
    Board findFirstByTitle(final String title);

}
