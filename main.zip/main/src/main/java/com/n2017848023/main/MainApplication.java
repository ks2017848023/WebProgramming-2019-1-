package com.n2017848023.main;


import com.n2017848023.main.domain.Basic;
import com.n2017848023.main.domain.Board;
import com.n2017848023.main.domain.BoardType;
import com.n2017848023.main.domain.Profile;
import com.n2017848023.main.repository.BasicRepository;
import com.n2017848023.main.repository.BoardRepository;
import com.n2017848023.main.repository.ProfileRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.time.LocalDateTime;
import java.util.stream.IntStream;

@SpringBootApplication
public class MainApplication {

	public static void main(String[] args) {
		SpringApplication.run(MainApplication.class, args);
	}

	@Bean
	public CommandLineRunner runner( BasicRepository basicRepository , ProfileRepository profileRepository) {
		//return (args) -> IntStream.rangeClosed(1, 200).forEach(index -> {
		return (args) -> IntStream.rangeClosed(1, 1).forEach(index -> {
			basicRepository.save(Basic.builder()
					.name("홍길동" ) //+ index
					.label("CEO" ) //+ index
					.email("home@gamil.com")
					.phone("012-123-4567")
					//.boardType(BoardType.free)
					.createdDate(LocalDateTime.now())
					//.updatedDate(LocalDateTime.now())
					.build());

			basicRepository.save(Basic.builder()
					.name("장길산" ) //+ index
					.label("CFO" ) //+ index
					.email("jang@gamil.com")
					.phone("123-456-7890")
					.createdDate(LocalDateTime.now())
					.build());

			basicRepository.save(Basic.builder()
					.name("춘향이" ) //+ index
					.label("CTO" ) //+ index
					.email("chun@gamil.com")
					.phone("234-567-8901")
					.createdDate(LocalDateTime.now())
					.build());


			profileRepository.save(Profile.builder()
					.network("트위터")
					.userName("@home")
					.url("https://www.twitter.com/@home")
					//.boardType(BoardType.free)
					.createDat(LocalDateTime.now())
					//.updatedDate(LocalDateTime.now())
					.build());

			profileRepository.save(Profile.builder()
					.network("페이스북")
					.userName("@home")
					.url("https://www.twitter.com/@home")
					.createDat(LocalDateTime.now())
					.build());

			profileRepository.save(Profile.builder()
					.network("인스타그램")
					.userName("@home")
					.url("https://www.twitter.com/@home")
					.createDat(LocalDateTime.now())
					.build());

		});
	}
}





