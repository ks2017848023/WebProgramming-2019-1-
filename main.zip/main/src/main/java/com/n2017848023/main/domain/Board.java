package com.n2017848023.main.domain;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

//Lombok
@Getter
@Setter
@NoArgsConstructor

//Jpa
@Entity
@Table
public class Board implements Serializable {

    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idx;

    @Column
    private String title;

    @Column
    private  String subTitle;

    @Column
    private String content;

    @Column
    @Enumerated(EnumType.STRING)
    private BoardType  boardType;

    @Column
    private LocalDateTime updatedDate;

    @Column
    private LocalDateTime createdDate;

    @OneToOne //
    private Basic basic;

    @OneToOne //
    private Profile profile;

    @Builder

    public Board(String title, String subTitle, String content, BoardType boardType, LocalDateTime updatedDate, LocalDateTime createdDate, Basic basic, Profile profile) {
        this.title = title;
        this.subTitle = subTitle;
        this.content = content;
        this.boardType = boardType;
        this.updatedDate = updatedDate;
        this.createdDate = createdDate;
        this.basic = basic;
        this.profile = profile;
    }
}
